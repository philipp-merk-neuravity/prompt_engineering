import fire
import sys

from data import HUMAN_EVAL
from evaluation import evaluate_functional_correctness

def entry_point(
    sample_file: str,
    k: str = "1,10,100",
    n_workers: int = 4,
    timeout: float = 3.0,
    problem_file: str = HUMAN_EVAL,
):
    """
    Evaluates the functional correctness of generated samples, and writes
    results to f"{sample_file}_results.jsonl.gz"
    """
    # Check if k is a string that needs to be split, or already an integer
    if isinstance(k, str):
        k = list(map(int, k.split(",")))
    elif isinstance(k, int):
        k = [k]  # Wrap the integer in a list
    else:
        raise ValueError("Unexpected type for 'k'. Must be either a str or int.")
    
    results = evaluate_functional_correctness(sample_file, k, n_workers, timeout, problem_file)
    print(results)

def main():
    fire.Fire(entry_point)

if __name__ == "__main__":
    sys.exit(main())